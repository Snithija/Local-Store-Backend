// This file exports the Express app for Vercel serverless functions
import app from '../server.js';

export default app;
